#ifndef attribute_tls_model_ie
#define attribute_tls_model_ie __attribute__ ((tls_model ("initial-exec")))
#endif


#ifdef HAVE_FEATURES_H
#include_next <features.h>
#else
#include <sys/cdefs.h>
#endif

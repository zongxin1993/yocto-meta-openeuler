#include_next <glibc/include/array_length.h>

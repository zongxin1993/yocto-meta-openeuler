#ifndef LOADINFO_H
#define LOADINFO_H
struct loaded_l10nfile;
#endif

/////////////////////////////////////////////////////////////////////////////
// Name:        class_archive.h
// Purpose:     wxArchive* classes group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_archive Archive support
@ingroup group_class

Classes for managing (eventually compressed) archives.

*/

